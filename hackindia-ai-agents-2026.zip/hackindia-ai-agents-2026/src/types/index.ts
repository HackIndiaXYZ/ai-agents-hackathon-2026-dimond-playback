// ─────────────────────────────────────────────
// Agent Configuration
// ─────────────────────────────────────────────

export type AgentRole =
  | 'planner'
  | 'researcher'
  | 'coder'
  | 'analyst'
  | 'writer'
  | 'critic'

export type AgentStatus = 'idle' | 'running' | 'done' | 'failed'

export interface AgentConfig {
  id: AgentRole
  name: string
  role: string          // Plain-language role description for Planner routing
  color: string         // Hex color for UI badge
  systemPrompt: string
  maxTokens: number
  temperature: number
}

// ─────────────────────────────────────────────
// Task Graph
// ─────────────────────────────────────────────

export type TaskStatus = 'pending' | 'running' | 'critic_review' | 'passed' | 'failed' | 'skipped'

export interface Task {
  id: string
  agent: AgentRole
  goal: string
  dependsOn: string[]   // Task IDs this task depends on
  status: TaskStatus
  output?: string
  criticScore?: number  // 0–1
  criticIssues?: string[]
  startedAt?: number
  completedAt?: number
  retryCount: number
}

export interface TaskGraph {
  goal: string          // Original user goal
  tasks: Task[]
  createdAt: number
}

// ─────────────────────────────────────────────
// Message Bus
// ─────────────────────────────────────────────

export type AgentEventType =
  | 'agent_started'
  | 'agent_token'
  | 'agent_done'
  | 'agent_failed'
  | 'critic_started'
  | 'critic_verdict'
  | 'task_status_changed'
  | 'goal_complete'
  | 'planner_graph'

export interface AgentEvent {
  type: AgentEventType
  taskId: string
  agent: AgentRole
  timestamp: number
  payload: {
    token?: string          // For agent_token events
    output?: string         // For agent_done
    error?: string          // For agent_failed
    status?: TaskStatus     // For task_status_changed
    graph?: TaskGraph       // For planner_graph
    verdict?: CriticVerdict // For critic_verdict
  }
}

// ─────────────────────────────────────────────
// Critic
// ─────────────────────────────────────────────

export interface CriticVerdict {
  passed: boolean
  score: number           // 0–1
  issues: string[]
  recommendation: 'pass' | 'retry' | 'skip'
  reasoning: string
}

// ─────────────────────────────────────────────
// Session State
// ─────────────────────────────────────────────

export interface SessionState {
  sessionId: string
  goal: string
  graph: TaskGraph | null
  events: AgentEvent[]
  isRunning: boolean
  isComplete: boolean
  finalReport: string | null
  startedAt: number | null
  completedAt: number | null
}

// ─────────────────────────────────────────────
// Claude API
// ─────────────────────────────────────────────

export interface ClaudeMessage {
  role: 'user' | 'assistant'
  content: string
}

export interface AgentCallOptions {
  agentId: AgentRole
  taskId: string
  messages: ClaudeMessage[]
  onToken: (token: string) => void
  onDone: (fullText: string) => void
  onError: (error: Error) => void
}
