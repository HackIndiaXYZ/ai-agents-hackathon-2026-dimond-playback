import type { AgentEvent, AgentEventType } from '@/types'

/**
 * In-browser typed event bus using the native EventTarget API.
 * All agent messages, task status changes, and Critic verdicts flow through here.
 * Components subscribe to specific event types — no polling, no global re-renders.
 */
class MessageBus extends EventTarget {
  private log: AgentEvent[] = []

  publish(event: AgentEvent): void {
    this.log.push(event)
    this.dispatchEvent(
      Object.assign(new Event(event.type), { detail: event })
    )
  }

  subscribe(type: AgentEventType, handler: (event: AgentEvent) => void): () => void {
    const listener = (e: Event) => handler((e as CustomEvent).detail as AgentEvent)
    this.addEventListener(type, listener)
    return () => this.removeEventListener(type, listener)
  }

  getLog(): AgentEvent[] {
    return [...this.log]
  }

  clear(): void {
    this.log = []
  }
}

export const messageBus = new MessageBus()
