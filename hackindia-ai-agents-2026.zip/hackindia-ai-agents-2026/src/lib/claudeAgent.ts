import { getAgentConfig } from '@/lib/agentConfig'
import type { AgentCallOptions } from '@/types'

const ANTHROPIC_API_URL = 'https://api.anthropic.com/v1/messages'
const MODEL = 'claude-sonnet-4-20250514'

/**
 * Streams a Claude Sonnet 4 response for a given agent role.
 * Each agent has its own system prompt and generation parameters from agentConfig.ts.
 * Tokens are emitted via onToken as they arrive; onDone fires with the full response.
 */
export async function streamAgentResponse(options: AgentCallOptions): Promise<void> {
  const { agentId, messages, onToken, onDone, onError } = options
  const config = getAgentConfig(agentId)
  const apiKey = import.meta.env.VITE_ANTHROPIC_API_KEY

  if (!apiKey) {
    // Demo mode: replay a pre-scripted response word-by-word
    await replayDemoResponse(agentId, onToken, onDone)
    return
  }

  try {
    const response = await fetch(ANTHROPIC_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: config.maxTokens,
        temperature: config.temperature,
        system: config.systemPrompt,
        messages,
        stream: true,
      }),
    })

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: { message: response.statusText } }))
      throw new Error(error?.error?.message ?? `HTTP ${response.status}`)
    }

    const reader = response.body?.getReader()
    if (!reader) throw new Error('No response body')

    const decoder = new TextDecoder()
    let fullText = ''
    let buffer = ''

    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      buffer += decoder.decode(value, { stream: true })
      const lines = buffer.split('\n')
      buffer = lines.pop() ?? ''

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue
        const data = line.slice(6).trim()
        if (data === '[DONE]') continue

        try {
          const event = JSON.parse(data)
          if (event.type === 'content_block_delta' && event.delta?.type === 'text_delta') {
            const token = event.delta.text
            fullText += token
            onToken(token)
          }
        } catch {
          // Malformed SSE chunk — skip
        }
      }
    }

    onDone(fullText)
  } catch (err) {
    onError(err instanceof Error ? err : new Error(String(err)))
  }
}

// ─────────────────────────────────────────────
// Demo Mode — pre-scripted responses per agent
// ─────────────────────────────────────────────

const DEMO_RESPONSES: Record<string, string> = {
  planner: `{"tasks":[{"id":"t1","agent":"researcher","goal":"Research the top 3 open-source vector databases: Chroma, Weaviate, and Qdrant","dependsOn":[]},{"id":"t2","agent":"analyst","goal":"Compare Chroma, Weaviate, and Qdrant on performance, scalability, and ease of use","dependsOn":["t1"]},{"id":"t3","agent":"coder","goal":"Write a Python quickstart example for each of the three vector databases","dependsOn":["t1"]},{"id":"t4","agent":"writer","goal":"Compile a final comparison report combining the analysis and code examples","dependsOn":["t2","t3"]}]}`,

  researcher: `## Open-Source Vector Databases — Research Summary\n\n**Chroma**\n- Fully open-source (Apache 2.0), embedded or client-server mode\n- Native Python and JavaScript SDKs\n- Designed for simplicity; popular in LangChain/LlamaIndex integrations\n- In-process mode stores data locally with zero setup\n\n**Weaviate**\n- Open-source (BSD 3-Clause), cloud-hosted option available\n- GraphQL + REST API; supports multi-modal vectors (text + image)\n- Built-in hybrid search (vector + BM25 keyword)\n- Production deployments at scale (10M+ vectors reported)\n\n**Qdrant**\n- Open-source (Apache 2.0), written in Rust for performance\n- gRPC + REST API; advanced filtering with payload indexing\n- Benchmarks show best-in-class QPS on ANN recall tasks\n- Kubernetes-ready with horizontal scaling out of the box\n\n### Sources & Confidence\n- Chroma features: High (official docs, GitHub)\n- Weaviate scale claims: Medium (vendor benchmarks)\n- Qdrant performance: High (ann-benchmarks.com, 2024)`,

  analyst: `## Key Takeaway\nQdrant leads on raw performance; Chroma leads on developer experience for prototyping; Weaviate leads on production multi-modal feature breadth.\n\n| Criteria | Chroma | Weaviate | Qdrant |\n|---|---|---|---|\n| Setup time | ★★★★★ (seconds) | ★★★☆☆ (minutes) | ★★★★☆ (minutes) |\n| QPS (1M vectors) | ★★★☆☆ | ★★★★☆ | ★★★★★ |\n| Filtering | ★★★☆☆ | ★★★★☆ | ★★★★★ |\n| Multi-modal | ★★☆☆☆ | ★★★★★ | ★★★☆☆ |\n| Horizontal scale | ★★☆☆☆ | ★★★★☆ | ★★★★★ |\n| SDK quality | ★★★★★ | ★★★★☆ | ★★★★☆ |\n\n**Recommended by use case:**\n- Prototype / RAG demo → Chroma\n- Production multi-modal search → Weaviate\n- High-throughput production ANN → Qdrant`,

  coder: `**Dependencies:** \`pip install chromadb weaviate-client qdrant-client sentence-transformers\`\n\n\`\`\`python\n# ── Chroma quickstart ──────────────────────────\nimport chromadb\n\nclient = chromadb.Client()\ncollection = client.create_collection("demo")\n\ncollection.add(\n    documents=["AgentForge is a multi-agent AI system", "Chroma is an open-source vector DB"],\n    ids=["doc1", "doc2"]\n)\n\nresults = collection.query(query_texts=["AI agents"], n_results=1)\nprint(results["documents"])  # [['AgentForge is a multi-agent AI system']]\n\n\n# ── Weaviate quickstart ────────────────────────\nimport weaviate\n\nclient = weaviate.connect_to_local()\ncollection = client.collections.create("Demo")\n\ncollection.data.insert({"text": "AgentForge multi-agent system"})\nresult = collection.query.near_text(query="AI agents", limit=1)\nprint(result.objects[0].properties)\nclient.close()\n\n\n# ── Qdrant quickstart ──────────────────────────\nfrom qdrant_client import QdrantClient\nfrom qdrant_client.models import Distance, VectorParams, PointStruct\n\nclient = QdrantClient(":memory:")\nclient.create_collection("demo", vectors_config=VectorParams(size=384, distance=Distance.COSINE))\n\nclient.upsert("demo", points=[PointStruct(id=1, vector=[0.1]*384, payload={"text": "AgentForge"})])\nresult = client.search("demo", query_vector=[0.1]*384, limit=1)\nprint(result[0].payload)\n\`\`\`\n\nEach snippet connects to a local/in-memory instance, inserts one document, and performs a similarity query. Chroma handles embedding automatically; Weaviate and Qdrant require you to supply vectors (use sentence-transformers to generate them in production).`,

  writer: `# Open-Source Vector Databases: Comparison Report\n\n## Executive Summary\nChroma, Weaviate, and Qdrant are the leading open-source vector databases for LLM-powered applications. Chroma excels for rapid prototyping with its zero-config setup. Weaviate offers the richest multi-modal and hybrid search features for production. Qdrant delivers the highest raw performance for large-scale, high-QPS deployments. Your choice should be driven by your scale requirements and team's existing stack.\n\n---\n\n## Detailed Comparison\n\n### Chroma\nChroma's killer feature is its developer experience — it runs in-process with a single Python import, making it the fastest path from idea to working RAG pipeline. It lacks advanced filtering and horizontal scaling, making it less suitable for production workloads above a few hundred thousand vectors.\n\n### Weaviate\nWeaviate's GraphQL API and native multi-modal support (text + image vectors in the same collection) set it apart. Its built-in hybrid search combines dense vector similarity with BM25 keyword ranking — a significant advantage for search applications where keyword precision matters alongside semantic similarity.\n\n### Qdrant\nWritten in Rust, Qdrant consistently tops ANN benchmarks for queries-per-second at recall parity. Its payload filtering system (filter by metadata before ANN search) is the most expressive of the three. For teams building high-throughput production pipelines, Qdrant is the clear performance leader.\n\n---\n\n## Code Examples\n\nSee the Coder agent output above for working Python quickstarts for all three databases.\n\n---\n\n## Next Steps\n1. **Start with Chroma** for any prototype or internal RAG tool — migrate to Qdrant or Weaviate if you hit scale limits.\n2. **Evaluate Weaviate** if your application requires multi-modal search or hybrid (vector + keyword) queries.\n3. **Benchmark on your own data** using [ann-benchmarks.com](https://ann-benchmarks.com) methodology before committing to a production choice — vendor benchmarks rarely match your specific embedding model and query distribution.`,

  critic: `{"passed":true,"score":0.88,"issues":["Writer output does not cite specific benchmark numbers from Analyst"],"recommendation":"pass","reasoning":"All outputs are factually consistent, well-structured, and complete. The Researcher correctly flagged medium confidence on Weaviate scale claims. Minor gap: Writer could have pulled the QPS rankings from Analyst more explicitly."}`,
}

async function replayDemoResponse(
  agentId: string,
  onToken: (token: string) => void,
  onDone: (full: string) => void
): Promise<void> {
  const text = DEMO_RESPONSES[agentId] ?? `[Demo] No pre-scripted response for agent: ${agentId}`
  const words = text.split('')

  for (const char of words) {
    onToken(char)
    await sleep(12 + Math.random() * 20)
  }

  onDone(text)
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}
