import type { Task, TaskGraph } from '@/types'

/**
 * Parses the Planner agent's JSON output into a validated TaskGraph.
 * Validates the DAG for cycles and unknown dependencies.
 */
export function parseTaskGraph(goal: string, plannerJson: string): TaskGraph {
  let raw: { tasks: Array<{ id: string; agent: string; goal: string; dependsOn: string[] }> }

  // Strip markdown fences if Planner included them despite instructions
  const cleaned = plannerJson.replace(/```json|```/g, '').trim()

  try {
    raw = JSON.parse(cleaned)
  } catch {
    throw new Error(`Planner output is not valid JSON: ${plannerJson.slice(0, 200)}`)
  }

  if (!Array.isArray(raw.tasks) || raw.tasks.length === 0) {
    throw new Error('Planner returned no tasks')
  }

  const taskIds = new Set(raw.tasks.map((t) => t.id))

  const tasks: Task[] = raw.tasks.map((t) => {
    for (const dep of t.dependsOn) {
      if (!taskIds.has(dep)) {
        throw new Error(`Task ${t.id} depends on unknown task ${dep}`)
      }
    }
    return {
      id: t.id,
      agent: t.agent as Task['agent'],
      goal: t.goal,
      dependsOn: t.dependsOn,
      status: 'pending',
      retryCount: 0,
    }
  })

  // Check for cycles via DFS
  detectCycles(tasks)

  return {
    goal,
    tasks,
    createdAt: Date.now(),
  }
}

/**
 * Returns the next batch of tasks that are ready to run:
 * - status === 'pending'
 * - all dependencies have status === 'passed'
 */
export function getReadyTasks(graph: TaskGraph): Task[] {
  const passedIds = new Set(graph.tasks.filter((t) => t.status === 'passed').map((t) => t.id))
  return graph.tasks.filter(
    (t) => t.status === 'pending' && t.dependsOn.every((dep) => passedIds.has(dep))
  )
}

/**
 * Returns true if all tasks have a terminal status (passed, failed, skipped).
 */
export function isGraphComplete(graph: TaskGraph): boolean {
  return graph.tasks.every((t) => ['passed', 'failed', 'skipped'].includes(t.status))
}

/**
 * Updates a single task's status (immutable — returns new graph).
 */
export function updateTaskStatus(
  graph: TaskGraph,
  taskId: string,
  patch: Partial<Task>
): TaskGraph {
  return {
    ...graph,
    tasks: graph.tasks.map((t) => (t.id === taskId ? { ...t, ...patch } : t)),
  }
}

// ─────────────────────────────────────────────
// Cycle detection (DFS)
// ─────────────────────────────────────────────

function detectCycles(tasks: Task[]): void {
  const graph = new Map<string, string[]>()
  for (const t of tasks) graph.set(t.id, t.dependsOn)

  const visited = new Set<string>()
  const stack = new Set<string>()

  function dfs(id: string): void {
    if (stack.has(id)) throw new Error(`Cycle detected involving task ${id}`)
    if (visited.has(id)) return
    visited.add(id)
    stack.add(id)
    for (const dep of graph.get(id) ?? []) dfs(dep)
    stack.delete(id)
  }

  for (const t of tasks) dfs(t.id)
}
