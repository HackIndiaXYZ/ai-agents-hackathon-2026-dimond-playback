import { create } from 'zustand'
import type { SessionState, AgentEvent, TaskGraph } from '@/types'

interface SessionStore extends SessionState {
  setGoal: (goal: string) => void
  setGraph: (graph: TaskGraph) => void
  addEvent: (event: AgentEvent) => void
  setRunning: (running: boolean) => void
  setComplete: (report: string) => void
  reset: () => void
}

const initialState: SessionState = {
  sessionId: crypto.randomUUID(),
  goal: '',
  graph: null,
  events: [],
  isRunning: false,
  isComplete: false,
  finalReport: null,
  startedAt: null,
  completedAt: null,
}

export const useSessionStore = create<SessionStore>((set) => ({
  ...initialState,

  setGoal: (goal) => set({ goal }),

  setGraph: (graph) => set({ graph }),

  addEvent: (event) =>
    set((state) => ({
      events: [...state.events, event],
      graph: state.graph
        ? {
            ...state.graph,
            tasks: state.graph.tasks.map((t) =>
              t.id === event.taskId && event.payload.status
                ? { ...t, status: event.payload.status }
                : t
            ),
          }
        : state.graph,
    })),

  setRunning: (isRunning) =>
    set((state) => ({
      isRunning,
      startedAt: isRunning && !state.startedAt ? Date.now() : state.startedAt,
    })),

  setComplete: (finalReport) =>
    set({ isComplete: true, isRunning: false, finalReport, completedAt: Date.now() }),

  reset: () =>
    set({ ...initialState, sessionId: crypto.randomUUID() }),
}))
