import { useCallback } from 'react'
import { useSessionStore } from '@/lib/sessionStore'
import { messageBus } from '@/lib/messageBus'
import { streamAgentResponse } from '@/lib/claudeAgent'
import { parseTaskGraph, getReadyTasks, isGraphComplete, updateTaskStatus } from '@/lib/taskGraph'
import { AGENT_CONFIGS } from '@/lib/agentConfig'
import type { Task, TaskGraph, CriticVerdict, AgentRole } from '@/types'

/**
 * Main orchestration hook.
 * Coordinates the Planner → Specialist agents → Critic loop.
 */
export function useAgentRunner() {
  const { setGoal, setGraph, addEvent, setRunning, setComplete, reset } = useSessionStore()

  const runGoal = useCallback(async (goal: string) => {
    reset()
    setGoal(goal)
    setRunning(true)

    try {
      // ── Step 1: Run Planner ──────────────────────────────────────
      const plannerOutput = await runAgent('planner', 'planner-task', [
        { role: 'user', content: `User goal: ${goal}` },
      ])

      let graph = parseTaskGraph(goal, plannerOutput)
      setGraph(graph)

      messageBus.publish({
        type: 'planner_graph',
        taskId: 'planner-task',
        agent: 'planner',
        timestamp: Date.now(),
        payload: { graph },
      })

      // ── Step 2: Execute task graph in dependency order ───────────
      const taskOutputs: Record<string, string> = {}

      while (!isGraphComplete(graph)) {
        const ready = getReadyTasks(graph)
        if (ready.length === 0) break // deadlock guard

        // Run all ready tasks in parallel
        await Promise.all(
          ready.map(async (task) => {
            graph = updateTaskStatus(graph, task.id, { status: 'running' })
            setGraph(graph)

            messageBus.publish({
              type: 'task_status_changed',
              taskId: task.id,
              agent: task.agent,
              timestamp: Date.now(),
              payload: { status: 'running' },
            })

            // Build context from upstream task outputs
            const context = task.dependsOn
              .map((dep) => `[${dep} output]\n${taskOutputs[dep] ?? '(no output)'}`)
              .join('\n\n')

            const userMessage = context
              ? `Your task: ${task.goal}\n\nContext from upstream agents:\n${context}`
              : `Your task: ${task.goal}`

            let agentOutput = ''
            try {
              agentOutput = await runAgent(task.agent, task.id, [
                { role: 'user', content: userMessage },
              ])
            } catch (err) {
              graph = updateTaskStatus(graph, task.id, { status: 'failed' })
              setGraph(graph)
              messageBus.publish({
                type: 'agent_failed',
                taskId: task.id,
                agent: task.agent,
                timestamp: Date.now(),
                payload: { error: String(err) },
              })
              return
            }

            // ── Step 3: Run Critic on agent output ───────────────
            graph = updateTaskStatus(graph, task.id, { status: 'critic_review' })
            setGraph(graph)

            messageBus.publish({
              type: 'critic_started',
              taskId: task.id,
              agent: 'critic',
              timestamp: Date.now(),
              payload: {},
            })

            const criticOutput = await runAgent('critic', `critic-${task.id}`, [
              {
                role: 'user',
                content: `Task specification: ${task.goal}\n\nAgent output to review:\n${agentOutput}`,
              },
            ])

            let verdict: CriticVerdict
            try {
              verdict = JSON.parse(criticOutput.replace(/```json|```/g, '').trim())
            } catch {
              verdict = { passed: true, score: 0.75, issues: [], recommendation: 'pass', reasoning: 'Could not parse Critic output — defaulting to pass.' }
            }

            messageBus.publish({
              type: 'critic_verdict',
              taskId: task.id,
              agent: 'critic',
              timestamp: Date.now(),
              payload: { verdict },
            })

            if (verdict.recommendation === 'pass') {
              taskOutputs[task.id] = agentOutput
              graph = updateTaskStatus(graph, task.id, {
                status: 'passed',
                output: agentOutput,
                criticScore: verdict.score,
                criticIssues: verdict.issues,
                completedAt: Date.now(),
              })
            } else if (verdict.recommendation === 'retry' && (graph.tasks.find(t => t.id === task.id)?.retryCount ?? 0) < 1) {
              // One retry per task
              graph = updateTaskStatus(graph, task.id, { status: 'pending', retryCount: 1 })
            } else {
              taskOutputs[task.id] = agentOutput // use output anyway
              graph = updateTaskStatus(graph, task.id, { status: 'skipped', output: agentOutput })
            }

            setGraph(graph)
            messageBus.publish({
              type: 'task_status_changed',
              taskId: task.id,
              agent: task.agent,
              timestamp: Date.now(),
              payload: { status: graph.tasks.find(t => t.id === task.id)?.status },
            })
          })
        )
      }

      // ── Step 4: Compile final report ─────────────────────────────
      const finalTask = graph.tasks.at(-1)
      const finalReport = finalTask?.output ?? Object.values(taskOutputs).join('\n\n---\n\n')

      messageBus.publish({
        type: 'goal_complete',
        taskId: 'done',
        agent: 'writer',
        timestamp: Date.now(),
        payload: { output: finalReport },
      })

      setComplete(finalReport)
    } catch (err) {
      setRunning(false)
      console.error('AgentRunner error:', err)
    }
  }, [reset, setGoal, setGraph, addEvent, setRunning, setComplete])

  return { runGoal }
}

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

async function runAgent(
  agentId: AgentRole,
  taskId: string,
  messages: Array<{ role: 'user' | 'assistant'; content: string }>
): Promise<string> {
  messageBus.publish({
    type: 'agent_started',
    taskId,
    agent: agentId,
    timestamp: Date.now(),
    payload: {},
  })

  return new Promise((resolve, reject) => {
    let tokens = ''

    streamAgentResponse({
      agentId,
      taskId,
      messages,
      onToken: (token) => {
        tokens += token
        messageBus.publish({
          type: 'agent_token',
          taskId,
          agent: agentId,
          timestamp: Date.now(),
          payload: { token },
        })
      },
      onDone: (full) => {
        messageBus.publish({
          type: 'agent_done',
          taskId,
          agent: agentId,
          timestamp: Date.now(),
          payload: { output: full },
        })
        resolve(full)
      },
      onError: reject,
    })
  })
}
