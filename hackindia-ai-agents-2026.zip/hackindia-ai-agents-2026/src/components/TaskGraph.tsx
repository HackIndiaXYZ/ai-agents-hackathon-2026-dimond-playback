import { AGENT_CONFIGS } from '@/lib/agentConfig'
import type { TaskGraph as TTaskGraph, Task, TaskStatus } from '@/types'

interface Props {
  graph: TTaskGraph
}

const STATUS_COLORS: Record<TaskStatus, string> = {
  pending: '#888780',
  running: '#534AB7',
  critic_review: '#BA7517',
  passed: '#1D9E75',
  failed: '#D85A30',
  skipped: '#888780',
}

const STATUS_LABELS: Record<TaskStatus, string> = {
  pending: 'pending',
  running: 'running',
  critic_review: 'reviewing',
  passed: 'passed',
  failed: 'failed',
  skipped: 'skipped',
}

export default function TaskGraph({ graph }: Props) {
  const { tasks } = graph

  // Simple horizontal layout: group tasks by "wave" (topological level)
  const levels = computeLevels(tasks)
  const maxLevel = Math.max(...Object.values(levels))
  const cols = maxLevel + 1

  const NODE_W = 140
  const NODE_H = 56
  const H_GAP = 60
  const V_GAP = 16
  const PAD_X = 40
  const PAD_Y = 40

  // Assign grid positions
  const levelCounts: Record<number, number> = {}
  const positions: Record<string, { x: number; y: number }> = {}

  for (const task of tasks) {
    const level = levels[task.id] ?? 0
    const count = levelCounts[level] ?? 0
    levelCounts[level] = count + 1

    const x = PAD_X + level * (NODE_W + H_GAP)
    const y = PAD_Y + count * (NODE_H + V_GAP)
    positions[task.id] = { x, y }
  }

  const maxRowCount = Math.max(...Object.values(levelCounts))
  const svgW = PAD_X * 2 + cols * NODE_W + (cols - 1) * H_GAP
  const svgH = PAD_Y * 2 + maxRowCount * NODE_H + (maxRowCount - 1) * V_GAP

  return (
    <div className="task-graph-wrap">
      <p className="task-graph-label">Task plan</p>
      <div className="task-graph-scroll">
        <svg
          width={svgW}
          height={svgH}
          viewBox={`0 0 ${svgW} ${svgH}`}
          style={{ display: 'block', minWidth: svgW }}
        >
          <defs>
            <marker id="tg-arrow" viewBox="0 0 10 10" refX="8" refY="5"
              markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M2 1L8 5L2 9" fill="none" stroke="#B4B2A9"
                strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </marker>
          </defs>

          {/* Edges */}
          {tasks.map((task) =>
            task.dependsOn.map((depId) => {
              const from = positions[depId]
              const to = positions[task.id]
              if (!from || !to) return null
              const x1 = from.x + NODE_W
              const y1 = from.y + NODE_H / 2
              const x2 = to.x
              const y2 = to.y + NODE_H / 2
              const cx = (x1 + x2) / 2
              return (
                <path
                  key={`${depId}-${task.id}`}
                  d={`M${x1},${y1} C${cx},${y1} ${cx},${y2} ${x2},${y2}`}
                  fill="none"
                  stroke="#B4B2A9"
                  strokeWidth="1"
                  markerEnd="url(#tg-arrow)"
                />
              )
            })
          )}

          {/* Nodes */}
          {tasks.map((task) => {
            const pos = positions[task.id]
            if (!pos) return null
            const color = STATUS_COLORS[task.status]
            const agentConfig = AGENT_CONFIGS[task.agent]
            const agentColor = agentConfig?.color ?? '#888'

            return (
              <g key={task.id} transform={`translate(${pos.x},${pos.y})`}>
                <rect
                  width={NODE_W}
                  height={NODE_H}
                  rx="6"
                  fill="var(--bg-primary, #fff)"
                  stroke={color}
                  strokeWidth="1.5"
                />
                {/* Agent color strip */}
                <rect width="4" height={NODE_H} rx="3" fill={agentColor} />

                {/* Agent name */}
                <text
                  x="14"
                  y="18"
                  fontSize="10"
                  fontWeight="500"
                  fill={agentColor}
                  fontFamily="Inter, sans-serif"
                >
                  {agentConfig?.name ?? task.agent}
                </text>

                {/* Task goal (truncated) */}
                <text
                  x="14"
                  y="33"
                  fontSize="10"
                  fill="#5F5E5A"
                  fontFamily="Inter, sans-serif"
                >
                  {task.goal.length > 38 ? task.goal.slice(0, 36) + '…' : task.goal}
                </text>

                {/* Status badge */}
                <text
                  x="14"
                  y="48"
                  fontSize="9"
                  fontWeight="500"
                  fill={color}
                  fontFamily="Inter, sans-serif"
                >
                  ● {STATUS_LABELS[task.status]}
                </text>

                {/* Critic score */}
                {task.criticScore !== undefined && (
                  <text
                    x={NODE_W - 8}
                    y="48"
                    fontSize="9"
                    fill="#888780"
                    textAnchor="end"
                    fontFamily="Inter, sans-serif"
                  >
                    {Math.round(task.criticScore * 100)}%
                  </text>
                )}
              </g>
            )
          })}
        </svg>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────
// Topological level assignment
// ─────────────────────────────────────────────
function computeLevels(tasks: Task[]): Record<string, number> {
  const levels: Record<string, number> = {}
  const taskMap = new Map(tasks.map((t) => [t.id, t]))

  function getLevel(id: string): number {
    if (levels[id] !== undefined) return levels[id]
    const task = taskMap.get(id)
    if (!task || task.dependsOn.length === 0) {
      levels[id] = 0
      return 0
    }
    const level = Math.max(...task.dependsOn.map(getLevel)) + 1
    levels[id] = level
    return level
  }

  for (const task of tasks) getLevel(task.id)
  return levels
}
