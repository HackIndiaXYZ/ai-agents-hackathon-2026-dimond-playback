import { useState } from 'react'
import { useAgentRunner } from '@/hooks/useAgentRunner'

const EXAMPLE_GOALS = [
  'Research the top 3 open-source vector databases and write a comparison report with a Python code example for each.',
  'Analyse the pros and cons of microservices vs monolith architecture and recommend which to use for a startup with 3 engineers.',
  'Write a beginner tutorial on how transformer attention works, with a NumPy code example showing self-attention from scratch.',
  'Compare the pricing, features, and ideal use cases of AWS Lambda, Google Cloud Run, and Azure Container Apps.',
]

export default function GoalInput() {
  const [goal, setGoal] = useState('')
  const { runGoal } = useAgentRunner()

  const handleSubmit = () => {
    const trimmed = goal.trim()
    if (!trimmed) return
    runGoal(trimmed)
  }

  return (
    <div className="goal-input-wrap">
      <div className="goal-hero">
        <h1 className="goal-title">What should the agents work on?</h1>
        <p className="goal-sub">
          Describe a goal in plain language. The Planner agent will decompose it into tasks
          and dispatch a team of specialist agents to research, code, analyse, and write.
        </p>
      </div>

      <div className="goal-card">
        <textarea
          className="goal-textarea"
          placeholder="e.g. Research the top open-source LLM frameworks and write a comparison report..."
          value={goal}
          onChange={(e) => setGoal(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) handleSubmit()
          }}
          rows={4}
          autoFocus
        />
        <div className="goal-actions">
          <span className="goal-hint">⌘ + Enter to run</span>
          <button
            className="btn-primary"
            onClick={handleSubmit}
            disabled={!goal.trim()}
          >
            Run agents →
          </button>
        </div>
      </div>

      <div className="examples-section">
        <p className="examples-label">Try an example</p>
        <div className="examples-list">
          {EXAMPLE_GOALS.map((eg, i) => (
            <button
              key={i}
              className="example-btn"
              onClick={() => setGoal(eg)}
            >
              {eg}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
