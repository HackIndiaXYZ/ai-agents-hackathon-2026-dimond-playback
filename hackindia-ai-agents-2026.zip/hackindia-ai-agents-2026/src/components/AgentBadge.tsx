import { AGENT_CONFIGS } from '@/lib/agentConfig'
import type { AgentRole, AgentStatus } from '@/types'

interface Props {
  agent: AgentRole
  status?: AgentStatus
  size?: 'sm' | 'md'
}

const STATUS_LABELS: Record<AgentStatus, string> = {
  idle: '',
  running: 'thinking...',
  done: 'done',
  failed: 'failed',
}

export default function AgentBadge({ agent, status = 'idle', size = 'md' }: Props) {
  const config = AGENT_CONFIGS[agent]
  if (!config) return null

  return (
    <span className={`agent-badge agent-badge--${size} agent-badge--${status}`}>
      <span
        className="agent-badge__dot"
        style={{ background: config.color }}
      />
      <span className="agent-badge__name">{config.name}</span>
      {status === 'running' && (
        <span className="agent-badge__pulse" style={{ background: config.color }} />
      )}
      {status !== 'idle' && STATUS_LABELS[status] && (
        <span className="agent-badge__status">{STATUS_LABELS[status]}</span>
      )}
    </span>
  )
}
