import { useEffect, useRef, useState } from 'react'
import { messageBus } from '@/lib/messageBus'
import { AGENT_CONFIGS } from '@/lib/agentConfig'
import type { AgentEvent, AgentRole } from '@/types'

interface FeedEntry {
  taskId: string
  agent: AgentRole
  tokens: string
  isDone: boolean
  isCritic: boolean
  timestamp: number
  criticPassed?: boolean
  criticScore?: number
}

export default function AgentFeed() {
  const [entries, setEntries] = useState<FeedEntry[]>([])
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const unsubs = [
      messageBus.subscribe('agent_started', (e: AgentEvent) => {
        if (e.agent === 'planner') return // planner shown separately
        setEntries((prev) => [
          ...prev,
          {
            taskId: e.taskId,
            agent: e.agent,
            tokens: '',
            isDone: false,
            isCritic: e.agent === 'critic',
            timestamp: e.timestamp,
          },
        ])
      }),

      messageBus.subscribe('agent_token', (e: AgentEvent) => {
        setEntries((prev) =>
          prev.map((entry) =>
            entry.taskId === e.taskId
              ? { ...entry, tokens: entry.tokens + (e.payload.token ?? '') }
              : entry
          )
        )
      }),

      messageBus.subscribe('agent_done', (e: AgentEvent) => {
        setEntries((prev) =>
          prev.map((entry) =>
            entry.taskId === e.taskId ? { ...entry, isDone: true } : entry
          )
        )
      }),

      messageBus.subscribe('critic_verdict', (e: AgentEvent) => {
        const verdict = e.payload.verdict
        setEntries((prev) =>
          prev.map((entry) =>
            entry.taskId === `critic-${e.taskId}` || entry.taskId === e.taskId
              ? {
                  ...entry,
                  isDone: true,
                  criticPassed: verdict?.passed,
                  criticScore: verdict?.score,
                }
              : entry
          )
        )
      }),
    ]

    return () => unsubs.forEach((u) => u())
  }, [])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [entries])

  if (entries.length === 0) {
    return (
      <div className="feed-empty">
        <div className="feed-spinner" />
        <p>Planner is thinking...</p>
      </div>
    )
  }

  return (
    <div className="agent-feed">
      {entries.map((entry, i) => {
        const config = AGENT_CONFIGS[entry.agent]
        const isCritic = entry.agent === 'critic'

        return (
          <div key={`${entry.taskId}-${i}`} className={`feed-entry ${isCritic ? 'feed-entry--critic' : ''}`}>
            <div className="feed-entry__header">
              <span
                className="feed-agent-dot"
                style={{ background: config?.color ?? '#888' }}
              />
              <span className="feed-agent-name" style={{ color: config?.color ?? '#888' }}>
                {config?.name ?? entry.agent}
              </span>
              {!entry.isDone && <span className="feed-thinking-dot" />}
              {entry.isDone && isCritic && entry.criticPassed !== undefined && (
                <span className={`feed-verdict ${entry.criticPassed ? 'feed-verdict--pass' : 'feed-verdict--fail'}`}>
                  {entry.criticPassed ? '✓ passed' : '✗ flagged'}
                  {entry.criticScore !== undefined && ` · ${Math.round(entry.criticScore * 100)}%`}
                </span>
              )}
            </div>

            <div className="feed-entry__body">
              <pre className="feed-tokens">{entry.tokens}</pre>
            </div>
          </div>
        )
      })}
      <div ref={bottomRef} />
    </div>
  )
}
