import { useSessionStore } from '@/lib/sessionStore'

export default function ReportView() {
  const { finalReport, goal, reset } = useSessionStore()

  if (!finalReport) return null

  const handleExport = () => {
    const blob = new Blob([finalReport], { type: 'text/markdown' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `agentforge-report-${Date.now()}.md`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="report-wrap">
      <div className="report-header">
        <div>
          <p className="report-label">Final report</p>
          <p className="report-goal">{goal}</p>
        </div>
        <div className="report-actions">
          <button className="btn-outline" onClick={handleExport}>
            Export .md
          </button>
          <button className="btn-outline" onClick={reset}>
            New goal
          </button>
        </div>
      </div>

      <div className="report-body">
        <pre className="report-content">{finalReport}</pre>
      </div>
    </div>
  )
}
