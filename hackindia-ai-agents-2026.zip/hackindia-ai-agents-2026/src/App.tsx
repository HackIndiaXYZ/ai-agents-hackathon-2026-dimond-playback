import { useSessionStore } from '@/lib/sessionStore'
import GoalInput from '@/components/GoalInput'
import AgentFeed from '@/components/AgentFeed'
import ReportView from '@/components/ReportView'
import TaskGraph from '@/components/TaskGraph'

export default function App() {
  const { isRunning, isComplete, graph } = useSessionStore()

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="header-inner">
          <div className="logo">
            <span className="logo-mark">▲</span>
            <span className="logo-name">AgentForge</span>
          </div>
          <span className="header-tag">HackIndia AI Agents 2026</span>
        </div>
      </header>

      <main className="app-main">
        {!isRunning && !isComplete && <GoalInput />}

        {(isRunning || isComplete) && graph && (
          <div className="workspace">
            <TaskGraph graph={graph} />
            <AgentFeed />
            {isComplete && <ReportView />}
          </div>
        )}
      </main>
    </div>
  )
}
